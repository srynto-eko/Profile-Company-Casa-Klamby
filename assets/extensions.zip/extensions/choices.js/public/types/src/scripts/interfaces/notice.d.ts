export interface Notice {
    response: boolean;
    notice: string;
}
//# sourceMappingURL=notice.d.ts.map